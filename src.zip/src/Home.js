import React from 'react';
import Header from './images/header.png';
import SideImage from './images/rashford.jpg';
import './Home.css';

function Home() {
    return (
        <div className="container mt-4">
            <img src={Header} alt="Description" className="img-fluid" />
            <div className="content">
            <div className="side-image">
                    <img src={SideImage} alt="Description" className="img-fluid" />
                </div>
                <div className="text">
                    <h1>Welcome to Manchester United Fan Page</h1>
                    <p>
                        Manchester United is one of the most successful and beloved football clubs in the world.
                        Founded in 1878, the club has a rich history, winning numerous domestic and international trophies.
                        The team's home ground is Old Trafford, located in Greater Manchester, England.
                    </p>
                    <p>
                        The club's nickname is the "Red Devils," and they have a massive fan following known as the "Red Army."
                        Manchester United has produced legendary players and memorable moments throughout its storied history.
                    </p>
                    <p>
                        Join us in celebrating the passion, history, and glory of Manchester United!
                    </p>
                    <ul>
                        <li>Founded: 1878</li>
                        <li>Nickname: Red Devils</li>
                        <li>Home Ground: Old Trafford</li>
                        <li>Major Honors: Premier League, Champions League, FA Cup</li>
                    </ul>
                    <button className="btn btn-primary">Explore More</button>
                </div>
            </div>
        </div>
    );
}

export default Home;
