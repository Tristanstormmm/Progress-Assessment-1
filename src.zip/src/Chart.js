import React, { useEffect } from 'react';
import Chart from 'chart.js/auto';
import './Chart.css';

function Chat() {
  useEffect(() => {
    const manUnitedStats = {
      labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023'],
      lineData: [69, 81, 66, 74, 66, 74, 72],
      barData: [81, 81, 66, 74, 66, 74, 72],
      doughnutData: [28, 41, 31],
      radarData: [65, 69, 72, 74, 71, 68, 73],
      polarAreaData: [18, 22, 15, 8, 20],
      newLineChartData: [45, 50, 48, 55, 60, 62, 58],
    };

    const lineChartCanvas = document.getElementById('lineChart');
    const barChartCanvas = document.getElementById('barChart');
    const doughnutChartCanvas = document.getElementById('doughnutChart');
    const radarChartCanvas = document.getElementById('radarChart');
    const polarAreaChartCanvas = document.getElementById('polarAreaChart');
    const newLineChartCanvas = document.getElementById('newLineChart');

    Chart.getChart(lineChartCanvas)?.destroy();
    Chart.getChart(barChartCanvas)?.destroy();
    Chart.getChart(doughnutChartCanvas)?.destroy();
    Chart.getChart(radarChartCanvas)?.destroy();
    Chart.getChart(polarAreaChartCanvas)?.destroy();
    Chart.getChart(newLineChartCanvas)?.destroy();

    new Chart(lineChartCanvas, {
      type: 'line',
      data: {
        labels: manUnitedStats.labels,
        datasets: [{
          label: 'Premier League Points',
          data: manUnitedStats.lineData,
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 2,
        }],
      },
    });

    new Chart(barChartCanvas, {
      type: 'bar',
      data: {
        labels: manUnitedStats.labels,
        datasets: [{
          label: 'Premier League Points',
          data: manUnitedStats.barData,
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          borderColor: 'rgba(255, 99, 132, 1)',
          borderWidth: 1,
        }],
      },
    });

    new Chart(doughnutChartCanvas, {
      type: 'doughnut',
      data: {
        labels: ['Wins', 'Draws', 'Losses'],
        datasets: [{
          data: manUnitedStats.doughnutData,
          backgroundColor: ['rgba(75, 192, 192, 0.5)', 'rgba(255, 206, 86, 0.5)', 'rgba(255, 99, 132, 0.5)'],
          borderColor: ['rgba(75, 192, 192, 1)', 'rgba(255, 206, 86, 1)', 'rgba(255, 99, 132, 1)'],
          borderWidth: 1,
        }],
      },
    });

    new Chart(radarChartCanvas, {
      type: 'radar',
      data: {
        labels: ['Attack', 'Midfield', 'Defense', 'Physical', 'Speed', 'Technique', 'Overall'],
        datasets: [{
          label: 'Player Ratings',
          data: manUnitedStats.radarData,
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          borderColor: 'rgba(255, 99, 132, 1)',
          borderWidth: 1,
        }],
      },
    });

    new Chart(newLineChartCanvas, {
      type: 'line',
      data: {
        labels: manUnitedStats.labels,
        datasets: [{
          label: 'Active Players',
          data: manUnitedStats.newLineChartData,
          borderColor: 'rgba(255, 99, 132, 1)',
          borderWidth: 2,
        }],
      },
    });

    new Chart(polarAreaChartCanvas, {
      type: 'polarArea',
      data: {
        labels: ['Forwards', 'Midfielders', 'Defenders', 'Goalkeepers', 'Coaching Staff'],
        datasets: [{
          data: manUnitedStats.polarAreaData,
          backgroundColor: ['rgba(255, 99, 132, 0.5)', 'rgba(54, 162, 235, 0.5)', 'rgba(255, 206, 86, 0.5)', 'rgba(75, 192, 192, 0.5)', 'rgba(153, 102, 255, 0.5)'],
          borderColor: ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)', 'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)'],
          borderWidth: 1,
        }],
      },
    });

  }, []);

  return (
    <div className="container mt-4">
      <h1>Manchester United FC Statistics</h1>
      <div className="chart-container">
        <div className="chart-item">
          <h2>Premier League Points Over the Years</h2>
          <div className="canvas-container">
            <canvas id="lineChart" width="400" height="200"></canvas>
          </div>
        </div>
        <div className="chart-item">
          <h2>Premier League Points Comparison</h2>
          <div className="canvas-container">
            <canvas id="barChart" width="400" height="200"></canvas>
          </div>
        </div>
        <div className="chart-item">
          <h2>Win-Draw-Loss Distribution</h2>
          <div className="canvas-container">
            <canvas id="doughnutChart" width="400" height="200"></canvas>
          </div>
        </div>
        <div className="chart-item">
          <h2>Active Players</h2>
          <div className="canvas-container">
            <canvas id="newLineChart" width="400" height="200"></canvas>
          </div>
        </div>
        <div className="chart-item">
          <h2>Player Ratings Radar Chart</h2>
          <div className="canvas-container">
            <canvas id="radarChart" width="400" height="200"></canvas>
          </div>
        </div>
        <div className="chart-item">
          <h2>Team Composition Distribution</h2>
          <div className="canvas-container">
            <canvas id="polarAreaChart" width="400" height="200"></canvas>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Chat;
